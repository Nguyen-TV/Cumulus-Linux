**Tổng hợp các command tham khảo.
Đây không phải là toàn bộ command cấu hình cho Cumulus Switch.**
